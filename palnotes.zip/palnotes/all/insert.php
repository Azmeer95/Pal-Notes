<?php
 
require('db.php');

$status = "";
if(isset($_POST['new']) && $_POST['new']==1)
{
$from =$_REQUEST['from'];
$to = $_REQUEST['to'];
$msg = $_REQUEST['msg'];

$ins_query="insert into messages (mfrom,mto,text) values ('$from','$to','$msg')";

//$mysqli_query($con, $ins_query) or die(mysql_error());

$con->query($ins_query) or die($con->error());

$status = "New Record Inserted Successfully.</br></br><a href='view.php'>View Inserted Record</a>";
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Insert New Record</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="dashboard.php">Dashboard</a> | <a href="view.php">View Records</a></p>

<div>
<h1>Insert New Record</h1>
<form name="form" method="post" action=""> 
	<input type="hidden" name="new" value="1" />
	<p><input type="number" name="from" placeholder="From (ID)" required /></p>
	<p><input type="number" name="to" placeholder="To (ID)" required /></p>
	<p><input type="text" name="msg" placeholder="Enter Message" required /></p>
	<p><input name="submit" type="submit" value="Submit" /></p>
</form>
<p style="color:#FF0000;"><?php echo $status; ?></p>

</div>
</div>
</body>
</html>
