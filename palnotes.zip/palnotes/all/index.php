<?php

Header("Location: dashboard.php"); ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Pal Notes Table Management</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">

<p><a href="dashboard.php">Dashboard</a></p>

</div>
</body>
</html>
